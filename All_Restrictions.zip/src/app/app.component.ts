import { Component } from '@angular/core';
import { HostListener } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Angular';
  key:any;

  //Mouse event controllers

   @HostListener('document:mousedown', ['$event'])
    handleMouseEvent(event: MouseEvent) { 
        
        console.log("Mouse key event occured");
        console.log("Mouse : "+event) 
        
        return false;
    }

    //Mouse context menu
 @HostListener('document:contextmenu', ['$event'])
  handleContextMenuEvent(event) { 
    return false;
  }
    // Keyboard event controllers 

     @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) { 
    this.key = event.key;
    console.log(event);
     if (event.keyCode == 123)
     {
       console.log("F12 pressed");
       return false;
     } 
    else if(event.ctrlKey && event.keyCode==83)
    {
      console.log("save key pressed : CTRL+S");
       return false;
    }
    else if(event.ctrlKey && event.keyCode==67)
    {
      console.log("copy key pressed : CTRL+C");
       return false;
    }
    else if(event.ctrlKey && event.keyCode==80)
    {
      console.log("save key pressed : CTRL+P");
       return false;
    }
    else if(event.ctrlKey && event.keyCode==65)
    {
      console.log("save key pressed : CTRL+A");
       return false;
    }
    else if(event.ctrlKey && event.shiftKey&&  event.keyCode==73)
    {
      console.log("save key pressed : CTRL+P");
       return false;
    }
    console.log("\n\nkey pressed : "+this.key+"");
  }

}
